
function regne_config(this_block)

  this_block.setTopLevelLanguage('VHDL');
  this_block.setEntityName('regne');
  this_block.addSimulinkInport('R');
  this_block.addSimulinkInport('Resetn');
  this_block.addSimulinkOutport('Q');

  % -----------------------------
  if (this_block.inputTypesKnown)
    % do input type checking, dynamic output type and generic setup in this code block.
    this_block.port('R').useHDLVector(true); 
    if (this_block.port('R').width ~= 8);
      this_block.setError('Input data type for port "Signal_in" must have width of 7.');
    end
    
    if (this_block.port('Resetn').width ~= 1);
      this_block.setError('Input data type for port "Resetn" must have width=1.');
    end

    this_block.port('Resetn').useHDLVector(false);
    qout_port = this_block.port('Q');
    input_bitwidth = this_block.port('R').width;
    
    % Set up the fixed parameters of the filter
    % Calculate the width of the output based on worst case values for data
    % and coefficicients
    output_bitwidth = input_bitwidth;
    % Set the output data type
    qout_port.makeSigned;
    qout_port.width = output_bitwidth;
    qout_port.binpt = 4;
  
    this_block.addGeneric('N', this_block.port('R').width);
  
  end  % if(inputTypesKnown)
  % -----------------------------

  % -----------------------------
   if (this_block.inputRatesKnown)
     setup_as_single_rate(this_block,'regne_clk','regne_ce')
   end  % if(inputRatesKnown)
  % -----------------------------

  this_block.addFile('regne.vhd');

return;


% ------------------------------------------------------------

function setup_as_single_rate(block,clkname,cename) 
  inputRates = block.inputRates; 
  uniqueInputRates = unique(inputRates); 
  if (length(uniqueInputRates)==1 & uniqueInputRates(1)==Inf) 
    block.setError('The inputs to this block cannot all be constant.'); 
    return; 
  end 
  if (uniqueInputRates(end) == Inf) 
     hasConstantInput = true; 
     uniqueInputRates = uniqueInputRates(1:end-1); 
  end 
  if (length(uniqueInputRates) ~= 1) 
    block.setError('The inputs to this block must run at a single rate.'); 
    return; 
  end 
  theInputRate = uniqueInputRates(1); 
  for i = 1:block.numSimulinkOutports 
     block.outport(i).setRate(theInputRate); 
  end 
  block.addClkCEPair(clkname,cename,theInputRate); 
  return; 

% ------------------------------------------------------------

