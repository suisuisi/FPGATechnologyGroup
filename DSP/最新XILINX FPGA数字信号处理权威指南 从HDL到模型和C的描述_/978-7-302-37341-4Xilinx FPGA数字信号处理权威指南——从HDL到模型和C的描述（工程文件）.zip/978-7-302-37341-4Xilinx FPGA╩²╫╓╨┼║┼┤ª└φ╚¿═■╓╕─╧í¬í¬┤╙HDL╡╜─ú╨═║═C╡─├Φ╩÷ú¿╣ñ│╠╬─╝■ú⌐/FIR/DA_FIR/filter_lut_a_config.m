
function filter_lut_a_config(this_block)

  this_block.setTopLevelLanguage('VHDL');
  this_block.setEntityName('filter_lut_a');
  this_block.tagAsCombinational;
  this_block.addSimulinkInport('D_in');
  this_block.addSimulinkOutport('Q');

  if (this_block.inputTypesKnown)
    if (this_block.port('D_in').width ~= 4);
      this_block.setError('Input data type for port "D_in" must have width=4.');
    end
    qout_port = this_block.port('Q');
    % Set up the fixed parameters of the filter
    % Calculate the width of the output based on worst case values for data
    % and coefficicients
    output_bitwidth = 23;
    % Set the output data type
    qout_port.makeSigned;
    qout_port.width = output_bitwidth;
    qout_port.binpt = 21;
    
    this_block.addGeneric('NC', this_block.port('Q').width);
  
  end  % if(inputTypesKnown)
  % -----------------------------

  % System Generator found no apparent clock signals in the HDL, assuming combinational logic.
  % -----------------------------
   if (this_block.inputRatesKnown)
     inputRates = this_block.inputRates; 
     uniqueInputRates = unique(inputRates); 
     outputRate = uniqueInputRates(1);
     for i = 2:length(uniqueInputRates)
       if (uniqueInputRates(i) ~= Inf)
         outputRate = gcd(outputRate,uniqueInputRates(i));
       end
     end  % for(i)
     for i = 1:this_block.numSimulinkOutports 
       this_block.outport(i).setRate(outputRate); 
     end  % for(i)
   end  % if(inputRatesKnown)

  this_block.addFile('filter_lut_a.vhd');

return;


