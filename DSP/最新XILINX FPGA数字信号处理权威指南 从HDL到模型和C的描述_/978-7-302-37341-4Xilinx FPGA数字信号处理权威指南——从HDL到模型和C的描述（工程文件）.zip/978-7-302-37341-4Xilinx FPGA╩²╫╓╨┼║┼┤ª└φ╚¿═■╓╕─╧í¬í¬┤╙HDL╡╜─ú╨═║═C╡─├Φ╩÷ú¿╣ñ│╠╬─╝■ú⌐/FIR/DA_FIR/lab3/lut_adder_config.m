
function lut_adder_config(this_block)

  this_block.setTopLevelLanguage('VHDL');
  this_block.setEntityName('lut_adder');
  this_block.tagAsCombinational;
  this_block.addSimulinkInport('lut_a');
  this_block.addSimulinkInport('lut_b');
  this_block.addSimulinkOutport('lut_out');

  % -----------------------------
  if (this_block.inputTypesKnown)
      
    % do input type checking, dynamic output type and generic setup in this code block.
    this_block.port('lut_a').useHDLVector(true); 
    if (this_block.port('lut_a').width ~= 23);
      this_block.setError('Input data type for port "lut_a" must have width of 23.');
    end
    this_block.port('lut_b').useHDLVector(true); 
    if (this_block.port('lut_b').width ~= 23);
      this_block.setError('Input data type for port "lut_a" must have width of 23.');
    end
    lut_out_port = this_block.port('lut_out');
    input_bitwidth = this_block.port('lut_a').width;
    
    % Set up the fixed parameters of the filter
    % Calculate the width of the output based on worst case values for data
    % and coefficicients
    output_bitwidth = input_bitwidth;
    % Set the output data type
    lut_out_port.makeSigned;
    lut_out_port.width = output_bitwidth;
    lut_out_port.binpt = 21;
  
    this_block.addGeneric('NC', this_block.port('lut_a').width);
  end  % if(inputTypesKnown)
  % -----------------------------

  % -----------------------------
   if (this_block.inputRatesKnown)
     inputRates = this_block.inputRates; 
     uniqueInputRates = unique(inputRates); 
     outputRate = uniqueInputRates(1);
     for i = 2:length(uniqueInputRates)
       if (uniqueInputRates(i) ~= Inf)
         outputRate = gcd(outputRate,uniqueInputRates(i));
       end
     end  % for(i)
     for i = 1:this_block.numSimulinkOutports 
       this_block.outport(i).setRate(outputRate); 
     end  % for(i)
   end  % if(inputRatesKnown)
  % -----------------------------

  this_block.addFile('lut_adder.vhd');

return;