#1 "dct_prj/dct.c"
#1 "dct_prj/dct.c" 1
#1 "<built-in>" 1
#1 "<built-in>" 3
#148 "<built-in>" 3
#1 "<command line>" 1







#1 "D:/Xilinx/Vivado_HLS/2013.3/common/technology/autopilot\\etc/autopilot_ssdm_op.h" 1
/* autopilot_ssdm_op.h*/
/*
 * Copyright (C) 2013 XILINX, Inc. 
 *
 * $Id$
 */
#238 "D:/Xilinx/Vivado_HLS/2013.3/common/technology/autopilot\\etc/autopilot_ssdm_op.h"
/*#define AP_SPEC_ATTR __attribute__ ((pure))*/



    /****** SSDM Intrinsics: OPERATIONS ***/
    // Interface operations
    void _ssdm_op_FifoRead() __attribute__ ((nothrow));
    void _ssdm_op_FifoWrite() __attribute__ ((nothrow));

    //typedef unsigned int __attribute__ ((bitwidth(1))) _uint1_;
    //_uint1_  _ssdm_op_FifoNbRead() SSDM_OP_ATTR;
    //_uint1_  _ssdm_op_FifoNbWrite() SSDM_OP_ATTR;
    //_uint1_  _ssdm_op_FifoCanRead() SSDM_OP_ATTR;
    //_uint1_  _ssdm_op_FifoCanWrite() SSDM_OP_ATTR;

    void _ssdm_op_IfRead() __attribute__ ((nothrow));
    void _ssdm_op_IfWrite() __attribute__ ((nothrow));
    //_uint1_ _ssdm_op_IfNbRead() SSDM_OP_ATTR;
    //_uint1_ _ssdm_op_IfNbWrite() SSDM_OP_ATTR;
    //_uint1_ _ssdm_op_IfCanRead() SSDM_OP_ATTR;
    //_uint1_ _ssdm_op_IfCanWrite() SSDM_OP_ATTR;

    // Stream Intrinsics
    void _ssdm_StreamRead() __attribute__ ((nothrow));
    void _ssdm_StreamWrite() __attribute__ ((nothrow));
    //_uint1_  _ssdm_StreamNbRead() SSDM_OP_ATTR;
    //_uint1_  _ssdm_StreamNbWrite() SSDM_OP_ATTR;
    //_uint1_  _ssdm_StreamCanRead() SSDM_OP_ATTR;
    //_uint1_  _ssdm_StreamCanWrite() SSDM_OP_ATTR;

    // Misc
    void _ssdm_op_MemShiftRead() __attribute__ ((nothrow));

    void _ssdm_op_Wait() __attribute__ ((nothrow));
    void _ssdm_op_Poll() __attribute__ ((nothrow));

    void _ssdm_op_Return() __attribute__ ((nothrow));

    /* SSDM Intrinsics: SPECIFICATIONS */
    void _ssdm_op_SpecSynModule() __attribute__ ((nothrow));
    void _ssdm_op_SpecTopModule() __attribute__ ((nothrow));
    void _ssdm_op_SpecProcessDecl() __attribute__ ((nothrow));
    void _ssdm_op_SpecProcessDef() __attribute__ ((nothrow));
    void _ssdm_op_SpecPort() __attribute__ ((nothrow));
    void _ssdm_op_SpecConnection() __attribute__ ((nothrow));
    void _ssdm_op_SpecChannel() __attribute__ ((nothrow));
    void _ssdm_op_SpecSensitive() __attribute__ ((nothrow));
    void _ssdm_op_SpecModuleInst() __attribute__ ((nothrow));
    void _ssdm_op_SpecPortMap() __attribute__ ((nothrow));

    void _ssdm_op_SpecReset() __attribute__ ((nothrow));

    void _ssdm_op_SpecPlatform() __attribute__ ((nothrow));
    void _ssdm_op_SpecClockDomain() __attribute__ ((nothrow));
    void _ssdm_op_SpecPowerDomain() __attribute__ ((nothrow));

    int _ssdm_op_SpecRegionBegin() __attribute__ ((nothrow));
    int _ssdm_op_SpecRegionEnd() __attribute__ ((nothrow));

    void _ssdm_op_SpecLoopName() __attribute__ ((nothrow));

    void _ssdm_op_SpecLoopTripCount() __attribute__ ((nothrow));

    int _ssdm_op_SpecStateBegin() __attribute__ ((nothrow));
    int _ssdm_op_SpecStateEnd() __attribute__ ((nothrow));

    void _ssdm_op_SpecBus() __attribute__ ((nothrow));
    void _ssdm_op_SpecFifo() __attribute__ ((nothrow));
    void _ssdm_op_SpecWire() __attribute__ ((nothrow));
    void _ssdm_op_SpecBuff() __attribute__ ((nothrow));
    void _ssdm_op_SpecMem() __attribute__ ((nothrow));

    void _ssdm_op_SpecPipeline() __attribute__ ((nothrow));
    void _ssdm_op_SpecDataflowPipeline() __attribute__ ((nothrow));


    void _ssdm_op_SpecLatency() __attribute__ ((nothrow));
    void _ssdm_op_SpecParallel() __attribute__ ((nothrow));
    void _ssdm_op_SpecProtocol() __attribute__ ((nothrow));
    void _ssdm_op_SpecOccurrence() __attribute__ ((nothrow));

    void _ssdm_op_SpecResource() __attribute__ ((nothrow));
    void _ssdm_op_SpecResourceLimit() __attribute__ ((nothrow));
    void _ssdm_op_SpecCHCore() __attribute__ ((nothrow));
    void _ssdm_op_SpecFUCore() __attribute__ ((nothrow));
    void _ssdm_op_SpecIFCore() __attribute__ ((nothrow));
    void _ssdm_op_SpecIPCore() __attribute__ ((nothrow));
    void _ssdm_op_SpecKeepValue() __attribute__ ((nothrow));
    void _ssdm_op_SpecMemCore() __attribute__ ((nothrow));

    void _ssdm_op_SpecExt() __attribute__ ((nothrow));
    /*void* _ssdm_op_SpecProcess() SSDM_SPEC_ATTR;
    void* _ssdm_op_SpecEdge() SSDM_SPEC_ATTR; */

    /* Presynthesis directive functions */
    void _ssdm_SpecArrayDimSize() __attribute__ ((nothrow));

    void _ssdm_RegionBegin() __attribute__ ((nothrow));
    void _ssdm_RegionEnd() __attribute__ ((nothrow));

    void _ssdm_Unroll() __attribute__ ((nothrow));
    void _ssdm_UnrollRegion() __attribute__ ((nothrow));

    void _ssdm_InlineAll() __attribute__ ((nothrow));
    void _ssdm_InlineLoop() __attribute__ ((nothrow));
    void _ssdm_Inline() __attribute__ ((nothrow));
    void _ssdm_InlineSelf() __attribute__ ((nothrow));
    void _ssdm_InlineRegion() __attribute__ ((nothrow));

    void _ssdm_SpecArrayMap() __attribute__ ((nothrow));
    void _ssdm_SpecArrayPartition() __attribute__ ((nothrow));
    void _ssdm_SpecArrayReshape() __attribute__ ((nothrow));

    void _ssdm_SpecStream() __attribute__ ((nothrow));

    void _ssdm_SpecExpr() __attribute__ ((nothrow));
    void _ssdm_SpecExprBalance() __attribute__ ((nothrow));

    void _ssdm_SpecDependence() __attribute__ ((nothrow));

    void _ssdm_SpecLoopMerge() __attribute__ ((nothrow));
    void _ssdm_SpecLoopFlatten() __attribute__ ((nothrow));
    void _ssdm_SpecLoopRewind() __attribute__ ((nothrow));

    void _ssdm_SpecFuncInstantiation() __attribute__ ((nothrow));
    void _ssdm_SpecFuncBuffer() __attribute__ ((nothrow));
    void _ssdm_SpecFuncExtract() __attribute__ ((nothrow));
    void _ssdm_SpecConstant() __attribute__ ((nothrow));

    void _ssdm_DataPack() __attribute__ ((nothrow));
    void _ssdm_SpecDataPack() __attribute__ ((nothrow));

    void _ssdm_op_SpecBitsMap() __attribute__ ((nothrow));


/*#define _ssdm_op_WaitUntil(X) while (!(X)) _ssdm_op_Wait(1);
#define _ssdm_op_Delayed(X) X */
#9 "<command line>" 2
#1 "<built-in>" 2
#1 "dct_prj/dct.c" 2

#1 "dct_prj/dct.h" 1







typedef short dct_data_t;





void dct(short input[1024/16], short output[1024/16]);
#2 "dct_prj/dct.c" 2


void dct_1d(dct_data_t src[8 /* defines the input matrix as 8x8 */], dct_data_t dst[8 /* defines the input matrix as 8x8 */])
{_ssdm_SpecArrayDimSize(dst,8);_ssdm_SpecArrayDimSize(src,8);
   unsigned int k, n;
   int tmp;
   const dct_data_t dct_coeff_table[8 /* defines the input matrix as 8x8 */][8 /* defines the input matrix as 8x8 */] = {

#1 "dct_prj/dct_coeff_table.txt" 1
 8192, 8192, 8192, 8192, 8192, 8192, 8192, 8192,
 11363, 9633, 6436, 2260, -2260, -6436, -9632,-11362,
 10703, 4433, -4433,-10703,-10703, -4433, 4433, 10703,
  9633, -2260,-11362, -6436, 6436, 11363, 2260, -9632,
  8192, -8192, -8192, 8192, 8192, -8191, -8191, 8192,
  6436,-11362, 2260, 9633, -9632, -2260, 11363, -6436,
  4433,-10703, 10703, -4433, -4433, 10703,-10703, 4433,
  2260, -6436, 9633,-11362, 11363, -9632, 6436, -2260
#9 "dct_prj/dct.c" 2

   };
_ssdm_SpecConstant(dct_coeff_table);
#10 "dct_prj/dct.c"


DCT_Outer_Loop:
   for (k = 0; k < 8 /* defines the input matrix as 8x8 */; k++) {_ssdm_op_SpecLoopName("DCT_Outer_Loop");_ssdm_RegionBegin("DCT_Outer_Loop");
DCT_Inner_Loop:
      for(n = 0, tmp = 0; n < 8 /* defines the input matrix as 8x8 */; n++) {_ssdm_op_SpecLoopName("DCT_Inner_Loop");_ssdm_RegionBegin("DCT_Inner_Loop");
         int coeff = (int)dct_coeff_table[k][n];
         tmp += src[n] * coeff;
      _ssdm_RegionEnd("DCT_Inner_Loop");}
      dst[k] = (((tmp) + (1 << ((13)-1))) >> 13);
   _ssdm_RegionEnd("DCT_Outer_Loop");}
}

void dct_2d(dct_data_t in_block[8 /* defines the input matrix as 8x8 */][8 /* defines the input matrix as 8x8 */],
      dct_data_t out_block[8 /* defines the input matrix as 8x8 */][8 /* defines the input matrix as 8x8 */])
{_ssdm_SpecArrayDimSize(out_block,8);_ssdm_SpecArrayDimSize(in_block,8);
   dct_data_t row_outbuf[8 /* defines the input matrix as 8x8 */][8 /* defines the input matrix as 8x8 */];
   dct_data_t col_outbuf[8 /* defines the input matrix as 8x8 */][8 /* defines the input matrix as 8x8 */], col_inbuf[8 /* defines the input matrix as 8x8 */][8 /* defines the input matrix as 8x8 */];
   unsigned i, j;

   // DCT rows
Row_DCT_Loop:
   for(i = 0; i < 8 /* defines the input matrix as 8x8 */; i++) {_ssdm_op_SpecLoopName("Row_DCT_Loop");_ssdm_RegionBegin("Row_DCT_Loop");
      dct_1d(in_block[i], row_outbuf[i]);
   _ssdm_RegionEnd("Row_DCT_Loop");}
   // Transpose data in order to re-use 1D DCT code
Xpose_Row_Outer_Loop:
   for (j = 0; j < 8 /* defines the input matrix as 8x8 */; j++)
{_ssdm_op_SpecLoopName("Xpose_Row_Outer_Loop");_ssdm_RegionBegin("Xpose_Row_Outer_Loop");
#38 "dct_prj/dct.c"
Xpose_Row_Inner_Loop:
      for(i = 0; i < 8 /* defines the input matrix as 8x8 */; i++)
         {_ssdm_op_SpecLoopName("Xpose_Row_Inner_Loop");_ssdm_RegionBegin("Xpose_Row_Inner_Loop");
#40 "dct_prj/dct.c"
col_inbuf[j][i] = row_outbuf[i][j];_ssdm_RegionEnd("Xpose_Row_Inner_Loop");}_ssdm_RegionEnd("Xpose_Row_Outer_Loop");}
   // DCT columns
Col_DCT_Loop:
   for (i = 0; i < 8 /* defines the input matrix as 8x8 */; i++) {_ssdm_op_SpecLoopName("Col_DCT_Loop");_ssdm_RegionBegin("Col_DCT_Loop");
      dct_1d(col_inbuf[i], col_outbuf[i]);
   _ssdm_RegionEnd("Col_DCT_Loop");}
   // Transpose data back into natural order
Xpose_Col_Outer_Loop:
   for (j = 0; j < 8 /* defines the input matrix as 8x8 */; j++)
{_ssdm_op_SpecLoopName("Xpose_Col_Outer_Loop");_ssdm_RegionBegin("Xpose_Col_Outer_Loop");
#49 "dct_prj/dct.c"
Xpose_Col_Inner_Loop:
      for(i = 0; i < 8 /* defines the input matrix as 8x8 */; i++)
         {_ssdm_op_SpecLoopName("Xpose_Col_Inner_Loop");_ssdm_RegionBegin("Xpose_Col_Inner_Loop");
#51 "dct_prj/dct.c"
out_block[j][i] = col_outbuf[i][j];_ssdm_RegionEnd("Xpose_Col_Inner_Loop");}_ssdm_RegionEnd("Xpose_Col_Outer_Loop");}
}

void read_data(short input[1024/16], short buf[8 /* defines the input matrix as 8x8 */][8 /* defines the input matrix as 8x8 */])
{_ssdm_SpecArrayDimSize(input,1024/16);_ssdm_SpecArrayDimSize(buf,8);
   int r, c;

RD_Loop_Row:
   for (r = 0; r < 8 /* defines the input matrix as 8x8 */; r++) {_ssdm_op_SpecLoopName("RD_Loop_Row");_ssdm_RegionBegin("RD_Loop_Row");
RD_Loop_Col:
      for (c = 0; c < 8 /* defines the input matrix as 8x8 */; c++)
         {_ssdm_op_SpecLoopName("RD_Loop_Col");_ssdm_RegionBegin("RD_Loop_Col");
#62 "dct_prj/dct.c"
buf[r][c] = input[r * 8 /* defines the input matrix as 8x8 */ + c];_ssdm_RegionEnd("RD_Loop_Col");}
   _ssdm_RegionEnd("RD_Loop_Row");}
}

void write_data(short buf[8 /* defines the input matrix as 8x8 */][8 /* defines the input matrix as 8x8 */], short output[1024/16])
{_ssdm_SpecArrayDimSize(output,1024/16);_ssdm_SpecArrayDimSize(buf,8);
   int r, c;

WR_Loop_Row:
   for (r = 0; r < 8 /* defines the input matrix as 8x8 */; r++) {_ssdm_op_SpecLoopName("WR_Loop_Row");_ssdm_RegionBegin("WR_Loop_Row");
WR_Loop_Col:
      for (c = 0; c < 8 /* defines the input matrix as 8x8 */; c++)
         {_ssdm_op_SpecLoopName("WR_Loop_Col");_ssdm_RegionBegin("WR_Loop_Col");
#74 "dct_prj/dct.c"
output[r * 8 /* defines the input matrix as 8x8 */ + c] = buf[r][c];_ssdm_RegionEnd("WR_Loop_Col");}
   _ssdm_RegionEnd("WR_Loop_Row");}
}

void dct(short input[1024/16], short output[1024/16])
{_ssdm_SpecArrayDimSize(input,1024/16);_ssdm_SpecArrayDimSize(output,1024/16);

   short buf_2d_in[8 /* defines the input matrix as 8x8 */][8 /* defines the input matrix as 8x8 */];
   short buf_2d_out[8 /* defines the input matrix as 8x8 */][8 /* defines the input matrix as 8x8 */];

   // Read input data. Fill the internal buffer.
   read_data(input, buf_2d_in);

   dct_2d(buf_2d_in, buf_2d_out);

   // Write out the results.
   write_data(buf_2d_out, output);
}
