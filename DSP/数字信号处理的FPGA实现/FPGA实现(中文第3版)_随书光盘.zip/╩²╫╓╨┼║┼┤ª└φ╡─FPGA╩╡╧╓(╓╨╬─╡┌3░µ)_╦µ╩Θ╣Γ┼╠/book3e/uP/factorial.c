x=1;
scanf k;
while (k != 1) {
    x = x * k;
    k= k - 1;
}
print x;
